<?php
namespace Octo;

use ReflectionClass;

class reflector extends ReflectionClass {}
