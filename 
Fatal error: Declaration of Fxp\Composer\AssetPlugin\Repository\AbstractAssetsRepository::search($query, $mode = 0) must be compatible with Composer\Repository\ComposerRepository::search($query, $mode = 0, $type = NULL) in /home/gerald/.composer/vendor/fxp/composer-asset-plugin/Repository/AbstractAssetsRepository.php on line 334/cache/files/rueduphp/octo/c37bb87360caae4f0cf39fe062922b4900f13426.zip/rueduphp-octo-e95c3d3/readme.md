<p align="center"><a href="https://github.com/rueduphp" target="_blank"><img src="https://avatars3.githubusercontent.com/u/22199444?v=3&s=125" style="width: 125px !important;"></a></p>

[![Build Status](https://travis-ci.org/rueduphp/octo.svg?branch=master)](https://travis-ci.org/rueduphp/octo)

## Octo Framework

Octo Framework is a PHP Framework to build applications.
It offers a set of components that implements general purpose
utility class for different scopes.

## Security Vulnerabilities

If you discover a security vulnerability within Octo, please send an e-mail to Gérald Plusquellec at gplusquellec@rueduphp.com. All security vulnerabilities will be promptly addressed.

## License

The Octo framework is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).
