<?php
    namespace Octo;

    class Sessionarray extends Now implements FastSessionInterface {}
