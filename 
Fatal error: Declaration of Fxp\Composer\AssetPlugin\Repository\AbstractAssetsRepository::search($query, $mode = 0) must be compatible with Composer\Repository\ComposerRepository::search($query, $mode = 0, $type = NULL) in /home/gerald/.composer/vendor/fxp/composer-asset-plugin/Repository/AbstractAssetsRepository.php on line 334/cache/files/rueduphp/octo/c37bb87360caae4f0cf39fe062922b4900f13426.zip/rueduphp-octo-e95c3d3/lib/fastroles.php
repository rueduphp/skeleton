<?php
    namespace Octo;

    class Fastroles extends Collection {}
