<?php
    namespace Octo;

    class Fastrole extends Object {}
