<?php
    return [
        'sqlite' => [
            'database' => ':memory:'
        ]
    ];
