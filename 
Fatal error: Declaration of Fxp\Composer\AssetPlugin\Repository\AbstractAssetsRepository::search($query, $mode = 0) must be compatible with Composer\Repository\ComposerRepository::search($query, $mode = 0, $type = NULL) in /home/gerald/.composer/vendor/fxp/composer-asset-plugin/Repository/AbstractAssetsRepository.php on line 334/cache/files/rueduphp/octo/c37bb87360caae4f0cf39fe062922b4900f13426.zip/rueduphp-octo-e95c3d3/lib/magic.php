<?php
    namespace Octo;

    class Magic extends Ghost {}
