<?php
    namespace Octo;

    class Fastuser extends Object {}
