<?php
    namespace Octo;

    class Context extends Ghost {}
