<?php
    namespace Octo;

    class Auth extends Authentication {}
