<?php
    namespace Octo;

    class Inner extends Container {};
