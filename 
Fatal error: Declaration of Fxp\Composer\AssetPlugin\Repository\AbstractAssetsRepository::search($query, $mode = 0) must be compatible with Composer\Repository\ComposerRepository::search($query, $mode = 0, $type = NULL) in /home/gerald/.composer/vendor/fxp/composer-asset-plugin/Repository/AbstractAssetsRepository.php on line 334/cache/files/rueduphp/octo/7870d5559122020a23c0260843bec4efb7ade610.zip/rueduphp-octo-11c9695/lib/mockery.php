<?php
    namespace Octo;

    class Mockery extends Ghost {}
