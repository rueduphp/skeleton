PHP Depend
=======
[![Build Status](https://travis-ci.org/pdepend/pdepend.svg?branch=master)](https://travis-ci.org/pdepend/pdepend)
[![Packagist](https://img.shields.io/packagist/dt/pdepend/pdepend.svg)](https://github.com/pdepend/pdepend)
[![codecov.io](https://codecov.io/gh/pdepend/pdepend/branch/master/graphs/badge.svg?branch=master)](https://codecov.io/github/pdepend/pdepend?branch=master)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/pdepend/pdepend/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/pdepend/pdepend/?branch=master)
